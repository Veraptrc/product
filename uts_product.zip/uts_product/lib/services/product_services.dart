import 'package:firebase_database/firebase_database.dart';

class ProductService {
  final DatabaseReference _database =
    FirebaseDatabase.instance.ref().child('product_list');

  Stream<Map<String, String>> getProductList() {
    return _database.onValue.map((event) {
      final Map<String, String> items = {};
      DataSnapshot snapshot = event.snapshot;
      // print('Snapshot data: ${snapshot.value}');
      if (snapshot.value != null) {
        Map<dynamic, dynamic> values = snapshot.value as Map<dynamic, dynamic>;
        values.forEach((key, value) {
          // print('Key: $key'); // Print the key
          // print('Value: $value'); // Print the value
          // items[key] = value['name']['kode_barang'] as String;
          items[key] =
          'Kode Barang : ${value['kode_barang']}\nNama Barang : ${value['name']} ';
        });
      }
      return items;
    });
  }

  void addProductItem(String itemName, kodeBarang) {
    _database.push().set({'kode_barang': kodeBarang, 'name': itemName});
  }

  Future<void> removeProductItem(String key) async {
    await _database.child(key).remove();
  }
}
