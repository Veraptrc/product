import 'package:uts_product/screens/home.dart';
import 'package:uts_product/services/product_services.dart';
import 'package:flutter/material.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<AddProductScreen> {
  final TextEditingController _controller1 = TextEditingController();
  final TextEditingController _controller2 = TextEditingController();
  final ProductService _productService = ProductService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daftar Belanja"),
      ),
      body: Column(
        children: [
          Padding(padding: EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller1,
                    decoration:
                    const InputDecoration(hintText: 'Masukkan Kode Barang'),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller2,
                    decoration:
                    const InputDecoration(hintText: 'Masukkan Nama Barang'),
                  ),
                ),
              ],
            ),
          ),
          TextButton(
            child: Text("Tambah"),
            onPressed: () {
              _productService.addProductItem(
                  _controller1.text, _controller2.text);
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => HomeScreen()));
            },
          ),
        ],
      ),
    );
  }
}