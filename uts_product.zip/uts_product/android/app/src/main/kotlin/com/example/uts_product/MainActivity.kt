package com.example.uts_product

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
